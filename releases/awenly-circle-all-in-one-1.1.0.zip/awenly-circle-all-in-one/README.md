# Awenly Circle — All-in-One 1.1.0

A single WordPress plugin adding an Awenly branded landing page, BuddyBoss-friendly navigation, practitioner and event content modules.

## Install
1. Back up the live WordPress database and files.
2. Upload the ZIP under Plugins → Add New Plugin → Upload Plugin.
3. Activate **Awenly Circle — All-in-One**.
4. Configure Awenly Circle in the WordPress admin.
5. Add `[awenly_home]` to a page and set it as the static homepage in Settings → Reading.
6. Use `[awenly_practitioner_directory]`, `[awenly_events]` and `[awenly_community_links]` on their respective pages.

## Included
- Branded landing page and responsive styling
- Admin settings for text and navigation URLs
- Practitioner and event custom post types
- Practitioner details and external booking URL
- Event date/time and external booking URL
- BuddyBoss navigation shortcuts

## Important
This plugin does not replace the active WordPress theme or BuddyBoss templates. It adds the Awenly design to its own shortcodes and content modules. It is a first integrated release, not a full booking/payment marketplace. Test on staging and back up before installing on production.
