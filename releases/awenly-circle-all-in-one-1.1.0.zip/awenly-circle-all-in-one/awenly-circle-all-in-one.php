<?php
/**
 * Plugin Name: Awenly Circle — All-in-One
 * Description: Awenly branded front end, BuddyBoss-friendly navigation, practitioner directory and events.
 * Version: 1.1.0
 * Author: Awenly Circle
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;
define('AWENLY_CIRCLE_PATH',plugin_dir_path(__FILE__));
define('AWENLY_CIRCLE_URL',plugin_dir_url(__FILE__));
require_once AWENLY_CIRCLE_PATH.'includes/modules.php';
register_activation_hook(__FILE__,function(){awenly_register_types();flush_rewrite_rules();});
register_deactivation_hook(__FILE__,function(){flush_rewrite_rules();});
add_action('init','awenly_register_types');
add_action('wp_enqueue_scripts',function(){
 wp_enqueue_style('awenly-circle-fonts','https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap',[],null);
 wp_enqueue_style('awenly-circle',AWENLY_CIRCLE_URL.'assets/awenly.css',[], '1.1.0');
});
function awenly_opts(){return wp_parse_args(get_option('awenly_circle_options',[]),['brand'=>'Awenly Circle','headline'=>'Find your space. Meet your people. Grow together.','subheadline'=>'A community for personal growth, healing and conscious living.','join'=>home_url('/register/'),'community'=>home_url('/activity/'),'directory'=>home_url('/practitioners/'),'events'=>home_url('/circle-events/')]);}
add_action('admin_menu',function(){add_menu_page('Awenly Circle','Awenly Circle','manage_options','awenly-circle','awenly_settings','dashicons-heart',58);});
add_action('admin_init',function(){register_setting('awenly_circle','awenly_circle_options',['sanitize_callback'=>function($v){$o=[];foreach(['brand','headline'] as $k)$o[$k]=sanitize_text_field($v[$k]??'');$o['subheadline']=sanitize_textarea_field($v['subheadline']??'');foreach(['join','community','directory','events'] as $k)$o[$k]=esc_url_raw($v[$k]??'');return $o;}]);});
function awenly_settings(){if(!current_user_can('manage_options'))return;$o=awenly_opts();?>
<div class="wrap"><h1>Awenly Circle — All-in-One</h1><p>Configure brand text and links. BuddyBoss and your active theme remain installed.</p><form method="post" action="options.php"><?php settings_fields('awenly_circle');?><table class="form-table">
<?php foreach(['brand'=>'Brand name','headline'=>'Homepage headline','subheadline'=>'Homepage description','join'=>'Registration URL','community'=>'Community URL','directory'=>'Practitioner directory URL','events'=>'Events URL'] as $k=>$label):?><tr><th><label for="aw-<?php echo esc_attr($k);?>"><?php echo esc_html($label);?></label></th><td><?php if($k==='subheadline'):?><textarea class="large-text" id="aw-<?php echo esc_attr($k);?>" name="awenly_circle_options[<?php echo esc_attr($k);?>]"><?php echo esc_textarea($o[$k]);?></textarea><?php else:?><input class="regular-text" id="aw-<?php echo esc_attr($k);?>" name="awenly_circle_options[<?php echo esc_attr($k);?>]" value="<?php echo esc_attr($o[$k]);?>"><?php endif;?></td></tr><?php endforeach;?></table><?php submit_button();?></form><p>Shortcodes: <code>[awenly_home]</code> <code>[awenly_community_links]</code> <code>[awenly_practitioner_directory]</code> <code>[awenly_events]</code></p></div><?php }
add_shortcode('awenly_home',function(){$o=awenly_opts();ob_start();?>
<div class="awenly"><header class="aw-top"><a class="aw-brand" href="<?php echo esc_url(home_url('/'));?>"><span class="aw-mark">✦</span><?php echo esc_html($o['brand']);?></a><nav><a href="<?php echo esc_url($o['community']);?>">Community</a><a href="<?php echo esc_url($o['directory']);?>">Practitioners</a><a href="<?php echo esc_url($o['events']);?>">Events</a></nav><a class="aw-join" href="<?php echo esc_url($o['join']);?>">Join the circle</a></header>
<section class="aw-hero"><div class="aw-copy"><small>CONNECT • LEARN • HEAL</small><h1><?php echo esc_html($o['headline']);?></h1><p><?php echo esc_html($o['subheadline']);?></p><a class="aw-button" href="<?php echo esc_url($o['join']);?>">Join our circle ↗</a></div><div class="aw-orbit"><i></i><b>✧</b></div></section>
<section class="aw-intro"><small>A SPACE TO GROW</small><h2>Meaningful connection.<br><em>Room to become.</em></h2><p>Discover a supportive community, learn from experienced practitioners and find experiences that nourish your next chapter.</p></section>
<section class="aw-cards"><?php foreach([['01 / CONNECT','Community','Meet like-minded people, join circles and share your journey.',$o['community'],'Explore community'],['02 / DISCOVER','Practitioners','Find therapists, coaches and guides who support your growth.',$o['directory'],'Find your guide'],['03 / EXPERIENCE','Events & learning','Take part in workshops, courses and live gatherings.',$o['events'],'See what’s happening']] as $c):?><a href="<?php echo esc_url($c[3]);?>"><small><?php echo esc_html($c[0]);?></small><h3><?php echo esc_html($c[1]);?></h3><p><?php echo esc_html($c[2]);?></p><b><?php echo esc_html($c[4]);?> ↗</b></a><?php endforeach;?></section><section class="aw-bottom"><h2>There is space for you in the circle.</h2><a class="aw-button" href="<?php echo esc_url($o['join']);?>">Become a member ↗</a></section><footer><span class="aw-brand"><span class="aw-mark">✦</span><?php echo esc_html($o['brand']);?></span><span>Connect • Learn • Heal</span></footer></div><?php return ob_get_clean();});
add_shortcode('awenly_community_links',function(){$o=awenly_opts();$links=['Activity feed'=>$o['community'],'Groups'=>home_url('/groups/'),'Members'=>home_url('/members/'),'Messages'=>home_url('/messages/')];$s='<div class="aw-links">';foreach($links as $n=>$u)$s.='<a href="'.esc_url($u).'">'.esc_html($n).' ↗</a>';return $s.'</div>';});
add_filter('the_content',function($content){if(is_singular('awenly_practitioner')&&in_the_loop()&&is_main_query()){$id=get_the_ID();$keys=['Session price'=>'fee','Format'=>'mode','Location'=>'location','Qualifications'=>'qualifications'];$html='<section class="aw-profile"><small>AWENLY CIRCLE PRACTITIONER</small><h1>'.esc_html(get_the_title()).'</h1><dl>';foreach($keys as $label=>$key){$v=get_post_meta($id,'_aw_'.$key,true);if($v)$html.='<div><dt>'.esc_html($label).'</dt><dd>'.esc_html($v).'</dd></div>';}$url=get_post_meta($id,'_aw_booking',true);$html.='</dl>';if($url)$html.='<a class="aw-button" href="'.esc_url($url).'" target="_blank" rel="noopener">Book a session ↗</a>';return $html.$content;}return $content;},20);
